### Hexlet tests and linter status:
[![Actions Status](https://github.com/IamYelena/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/IamYelena/python-project-49/actions)


[![asciicast](https://asciinema.org/a/583229.svg)](https://asciinema.org/a/583229)




[![asciicast](https://asciinema.org/a/584397.svg)](https://asciinema.org/a/584397)


[![asciicast](https://asciinema.org/a/584673.svg)](https://asciinema.org/a/584673)