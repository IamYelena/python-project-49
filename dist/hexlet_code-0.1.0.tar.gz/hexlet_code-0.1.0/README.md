### Hexlet tests and linter status:
[![Actions Status](https://github.com/IamYelena/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/IamYelena/python-project-49/actions)


<a href="https://asciinema.org/a/eFmpzTEmKxJ6GIp2xDKxdIGn3" target="_blank"><img src="https://asciinema.org/a/eFmpzTEmKxJ6GIp2xDKxdIGn3.svg" /></a>
