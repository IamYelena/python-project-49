#!/usr/bin/env python3


def welcome():
    print("!!!!!")


def main():
    welcome()



if __name__ == '__main__':
    main()

